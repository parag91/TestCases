package cases;

import java.util.concurrent.TimeUnit;
import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class TestCases {

	@Test
	public void EmailTest() {
		System.setProperty("webdriver.gecko.driver", "E:\\Automation\\PTA\\geckodriver\\geckodriver.exe");
		WebDriver driver = new FirefoxDriver();		
		//Open URL
		driver.get("http://localhost:4200");
		//Click without entering emailID
		driver.findElement(By.xpath("html/body/app-root/app-login/nav/div/div[2]/button")).click();
		//Check Validation
		Assert.assertEquals(driver.findElement(By.xpath("html/body/app-root/app-login/nav/div/div[2]/div[2]/h2")).getText(), "Email cannot be empty");
		//Click without entering invalid emailID
		driver.findElement(By.id("email")).sendKeys("xyz");
		driver.findElement(By.xpath("html/body/app-root/app-login/nav/div/div[2]/button")).click();
		//Check Validation
		Assert.assertEquals(driver.findElement(By.xpath("html/body/app-root/app-login/nav/div/div[2]/div[2]/h2")).getText(), "xyz is not a valid Email");
		// Enter emailID
		driver.findElement(By.id("email")).clear();
		driver.findElement(By.id("email")).sendKeys("xyz@gmail.com");
		//wait 5 secs for userid to be entered
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.xpath("html/body/app-root/app-login/nav/div/div[2]/button")).click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		//check Back button
		driver.findElement(By.xpath("html/body/app-root/test-details/div[2]/div/button[1]")).click();
		Assert.assertEquals(driver.findElement(By.xpath("html/body/app-root/app-login/nav/div/div[2]/div[1]/label")).getText(), "Enter Your Email :");
		driver.close();
	}

	@Test
	public void NoSelection() {
		System.setProperty("webdriver.gecko.driver", "E:\\Automation\\PTA\\geckodriver\\geckodriver.exe");
		WebDriver driver = new FirefoxDriver();
		//driver.manage().window().maximize();
		//WebDriverWait driverWait = new WebDriverWait(driver, 60);
		//Open URL
		driver.get("http://localhost:4200");	
		// Enter emailID
		driver.findElement(By.id("email")).clear();
		driver.findElement(By.id("email")).sendKeys("xyz@gmail.com");
		//wait 5 secs for userid to be entered
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		//Click Enter Test
		driver.findElement(By.xpath("html/body/app-root/app-login/nav/div/div[2]/button")).click();
		// Click Submit with any selection
		driver.findElement(By.xpath("html/body/app-root/test-details/div[2]/div/button[2]")).click();
		
		/*Assert.assertEquals(driver.findElement(By.xpath("html/body/app-root/app-login/nav/div/div[2]/div[1]/label")).getText(), "Enter Your Email :");*/
		
		driver.close();
	}
	
	@Test
	public void AfterSelection() {
		//initialize Firefox driver
		System.setProperty("webdriver.gecko.driver", "E:\\Automation\\PTA\\geckodriver\\geckodriver.exe");
		WebDriver driver = new FirefoxDriver();
		//driver.manage().window().maximize();
		//Open URL
		driver.get("http://localhost:4200");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		// Enter emailID
		driver.findElement(By.id("email")).clear();
		driver.findElement(By.id("email")).sendKeys("xyz@gmail.com");
		//wait 5 secs for userid to be entered
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("html/body/app-root/app-login/nav/div/div[2]/button")).click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		// choose options 
		driver.findElement(By.id("md-radio-2")).click();
		driver.findElement(By.id("md-radio-7")).click();
		driver.findElement(By.id("md-radio-11")).click();
		driver.findElement(By.id("md-radio-15")).click();
		driver.findElement(By.id("md-radio-19")).click();
		//switch to second tab
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("window.scrollBy(0,-250)", "");
		driver.findElement(By.id("md-tab-label-0-1")).click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		// choose options 
		driver.findElement(By.id("md-radio-24")).click();
		driver.findElement(By.id("md-radio-28")).click();
		driver.findElement(By.id("md-radio-32")).click();
		//jse.executeScript("arguments[0].scrollIntoView();", driver.findElement(By.id("md-radio-47")));
		//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		driver.findElement(By.id("md-radio-35")).click();
		driver.findElement(By.id("md-radio-42")).click();
		driver.findElement(By.id("md-radio-47")).click();
		//jse.executeScript("arguments[0].scrollIntoView();", driver.findElement(By.id("md-radio-60")));
		//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		driver.findElement(By.id("md-radio-52")).click();
		driver.findElement(By.id("md-radio-57")).click();
		driver.findElement(By.id("md-radio-62")).click();
		//switch to third tab
		jse.executeScript("window.scrollBy(0,-1000)", "");
		driver.findElement(By.id("md-tab-label-0-2")).click();
		//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		// choose options 
		driver.findElement(By.id("md-radio-68")).click();
		driver.findElement(By.id("md-radio-74")).click();
		driver.findElement(By.id("md-radio-80")).click();
		//jse.executeScript("window.scrollBy(0,300)", "");
		driver.findElement(By.id("md-radio-86")).click();
		driver.findElement(By.id("md-radio-92")).click();
		
		//switch to fourth tab
		jse.executeScript("window.scrollBy(0,-1000)", "");
		driver.findElement(By.id("md-tab-label-0-3")).click();
		//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		//driverWait.until(ExpectedConditions.elementToBeClickable(By.id("md-radio-129")));
		//Thread.sleep(3000);
		// choose options 
		driver.findElement(By.id("md-radio-98")).click();
		driver.findElement(By.id("md-radio-104")).click();
		driver.findElement(By.id("md-radio-110")).click();
		driver.findElement(By.id("md-radio-117")).click();
		driver.findElement(By.id("md-radio-123")).click();
		driver.findElement(By.id("md-radio-129")).click();	
		
		driver.findElement(By.xpath("html/body/app-root/test-details/div[2]/div/button[2]")).click();

		/*Assert.assertEquals(driver.findElement(By.xpath("html/body/app-root/app-login/nav/div/div[2]/div[1]/label")).getText(), "Enter Your Email :");*/
		
		driver.close();
		
	}
}
